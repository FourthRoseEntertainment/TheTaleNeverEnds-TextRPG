#include "input.h"

Minput::Minput()
{
}

Minput::~Minput()
{
}

std::string Minput::UserInput(std::string passed_output)
{
	std::string tempString;
	bool restart = false;
	std::vector<char> input;
	input.push_back('y');
	input.push_back('n');
	std::vector<std::string> output;
	output.push_back("Yes");
	output.push_back("No");
	OutputChoice(passed_output, NULL);
	while (std::getline(std::cin, tempString) || restart == true)
	{
		std::cout << std::endl << "Is this correct? : " << tempString << std::endl;
		OutputChoice(output, input);
		switch (InputChoice(input))
		{
		case 'Y':
		case 'y':
			return tempString;
			break;
		case 'N':
		case 'n':
			OutputChoice(passed_output, NULL);
			tempString = "";
			restart = true;
			break;
		default:
			OutputChoice(passed_output, NULL);
			tempString = "";
			restart = true;
			break;
		}
	}
	std::cout << "ERROR!  Failed input!" << std::endl;
	return NULL;
}

char Minput::ChoiceHandler(std::vector<std::string> output, std::vector<char> input)
{
	OutputChoice(output, input);
	return InputChoice(input);;
}

void Minput::OutputChoice(std::vector<std::string> output, std::vector<char> input)
{
	for (unsigned int i = 0; i < output.size(); i++)
	{
		std::cout << "Please input (" << input[i] << ") for " << output[i] << std::endl;
	}
}

char Minput::InputChoice(std::vector<char> input)
{
	bool restart = true;
	while (restart)
	{
		char tempInput = NULL;
		tempInput = _getch();
		for (unsigned int i = 0; i < input.size(); i++)
		{
			if (input[i] == tempInput) { return tempInput; }
		}
		std::cout << "Your entry (" << tempInput << ") does not match the options, please try again!" << std::endl;
	}
	return NULL;
}

char Minput::ChoiceHandler(std::string output, char input)
{
	OutputChoice(output, input);
	return InputChoice(input);
}

void Minput::OutputChoice(std::string output, char input)
{
	if (input == NULL)
	{
		std::cout << output << std::endl;
	}
	else
	{
		std::cout << output << " : " << input << std::endl;
	}
}

char Minput::InputChoice(char input)
{
	std::cout << "Just one option?" << std::endl;
	bool restart = true;
	while (restart)
	{
		char tempInput = _getch();
		if (tempInput == input) { return tempInput; }
		else
		{
			tempInput = NULL;
			std::cout << "Your entry does not match the options, please try again!" << std::endl;
			break;
		}
	}
	return NULL;
}